﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace EmployeeTest
{
    public partial class main : System.Web.UI.Page
    {
        //Declaring connection string
        string cs = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\User\\source\\repos\\EmployeeTest\\EmployeeTest\\App_Data\\EmployeeDB.mdf;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            

            //Hide Records
            lblShowAll.Visible = false;
            GridView1.Visible = false;

            //Hide Search 
            lblSearch.Visible = false;
            gvCustomers.Visible = false;
            txtSearch.Visible = false;
            btnSearch.Visible = false;

            //Hide Add new employees
            lbladdnew.Visible = false;
            txtFirstName.Visible = false;
            txtSurname.Visible = false;
            txtDOB.Visible = false;
            txtCell.Visible = false;
            txtEmail.Visible = false;
            lblFirstName.Visible = false;
            lblSurname.Visible = false;
            lblDOB.Visible = false;
            lblCell.Visible = false;
            lblEmail.Visible = false;
            BtnRegister.Visible = false;
            btnCancel.Visible = false;

            lblmsg.Visible = false;

            //Hide Update Controls
            txtUpdateFirstName.Visible = false;
            txtUpdateSurname.Visible = false;
            txtUpdateDoB.Visible = false;
            txtUpdateCell.Visible = false;
            txtUpdateEmail.Visible = false;
            lblUpdateFirstName.Visible = false;
            lblUpdateSurname.Visible = false;
            lblUpdateDOB.Visible = false;
            lblUpdateCell.Visible = false;
            lblUpdateEmail.Visible = false;
            lblupdatemsg.Visible = false;
            lblupdate.Visible = false;
            DropDownList1.Visible = false;
            btnUpdate.Visible = false;

            btnSelectID.Visible = false;

        }

        //Method for showing all records
        public DataTable DisplayRecords()
        {
            SqlConnection con = new SqlConnection(cs);
            SqlDataAdapter Adp = new SqlDataAdapter("select * from EmployeeTable", con);
            DataTable Dt = new DataTable();
            Adp.Fill(Dt);
            GridView1.DataSource = Dt;
            GridView1.DataBind();
            return Dt;


        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //Searching for a record using the FirstName of the person
            using (SqlConnection con = new SqlConnection(cs))
            {

                string query = "select * from EmployeeTable where FirstName like '" + txtSearch.Text + "%'";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                gvCustomers.DataSource = ds;
                gvCustomers.DataBind();
                lblSearch.Visible = true;
                gvCustomers.Visible = true;
                txtSearch.Visible = true;
                btnSearch.Visible = true;
          
            }
        }

        protected void btnShowAllRecords_Click(object sender, EventArgs e)
        {
            //Method displaying records
            DisplayRecords();
            lblShowAll.Visible = true;
            GridView1.Visible = true;

            //Hide Update Controls
            txtUpdateFirstName.Visible = false;
            txtUpdateSurname.Visible = false;
            txtUpdateDoB.Visible = false;
            txtUpdateCell.Visible = false;
            txtUpdateEmail.Visible = false;
            lblUpdateFirstName.Visible = false;
            lblUpdateSurname.Visible = false;
            lblUpdateDOB.Visible = false;
            lblUpdateCell.Visible = false;
            lblUpdateEmail.Visible = false;
            lblupdatemsg.Visible = false;
            lblupdate.Visible = false;
            DropDownList1.Visible = false;
            btnUpdate.Visible = false;
            btnSelectID.Visible = false;
        }

        protected void BtnSearch1_Click1(object sender, EventArgs e)
        {
            //Show Controls to search for employee
            lblSearch.Visible = true;
            gvCustomers.Visible = true;
            txtSearch.Visible = true;
            btnSearch.Visible = true;

            //Hide Update Controls
            txtUpdateFirstName.Visible = false;
            txtUpdateSurname.Visible = false;
            txtUpdateDoB.Visible = false;
            txtUpdateCell.Visible = false;
            txtUpdateEmail.Visible = false;
            lblUpdateFirstName.Visible = false;
            lblUpdateSurname.Visible = false;
            lblUpdateDOB.Visible = false;
            lblUpdateCell.Visible = false;
            lblUpdateEmail.Visible = false;
            lblupdatemsg.Visible = false;
            lblupdate.Visible = false;
            DropDownList1.Visible = false;
            btnSelectID.Visible = false;
            btnUpdate.Visible = false;
        }

        protected void BtnAddEmployee_Click(object sender, EventArgs e)
        {
            //Show Controls of Adding Employees
            lbladdnew.Visible = true;
            txtFirstName.Visible = true;
            txtSurname.Visible = true;
            txtDOB.Visible = true;
            txtCell.Visible = true;
            txtEmail.Visible = true;
            lblFirstName.Visible = true;
            lblSurname.Visible = true;
            lblDOB.Visible = true;
            lblCell.Visible = true;
            lblEmail.Visible = true;
            BtnRegister.Visible = true;
            btnCancel.Visible = true;

            //Hide Update Controls
            txtUpdateFirstName.Visible = false;
            txtUpdateSurname.Visible = false;
            txtUpdateDoB.Visible = false;
            txtUpdateCell.Visible = false;
            txtUpdateEmail.Visible = false;
            lblUpdateFirstName.Visible = false;
            lblUpdateSurname.Visible = false;
            lblUpdateDOB.Visible = false;
            lblUpdateCell.Visible = false;
            lblUpdateEmail.Visible = false;
            lblupdatemsg.Visible = false;
            lblupdate.Visible = false;
            DropDownList1.Visible = false;
            btnUpdate.Visible = false;
            btnSelectID.Visible = false;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //Cancels input text
            txtFirstName.Text = "";
            txtSurname.Text = "";
            txtDOB.Text = "";
            txtCell.Text = "";
            txtEmail.Text = "";
        }

        protected void BtnRegister_Click(object sender, EventArgs e)
        {
            //Showing Controllers for registeration
            lbladdnew.Visible = true;
            txtFirstName.Visible = true;
            txtSurname.Visible = true;
            txtDOB.Visible = true;
            txtCell.Visible = true;
            txtEmail.Visible = true;
            lblFirstName.Visible = true;
            lblSurname.Visible = true;
            lblDOB.Visible = true;
            lblCell.Visible = true;
            lblEmail.Visible = true;
            BtnRegister.Visible = true;
            btnCancel.Visible = true;

            //adding new employee to the database

            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("InsertProcedure", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@Surname", txtSurname.Text);
                cmd.Parameters.AddWithValue("@DateOfBirth", txtDOB.Text);
                cmd.Parameters.AddWithValue("@Cell", txtCell.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                con.Open();
                int k = cmd.ExecuteNonQuery();
                if (k != 0)
                {
                    lblmsg.Text = "Record Inserted Succesfully into the Database";
                    lblmsg.ForeColor = System.Drawing.Color.CornflowerBlue;
                }
                con.Close();


            }

           
        }

        protected void BtnUpdateEmployee_Click(object sender, EventArgs e)
        {
            //Showing all Update Controls
            txtUpdateFirstName.Visible = true;
            txtUpdateSurname.Visible = true;
            txtUpdateDoB.Visible = true;
            txtUpdateCell.Visible = true;
            txtUpdateEmail.Visible = true;
            lblUpdateFirstName.Visible = true;
            lblUpdateSurname.Visible = true;
            lblUpdateDOB.Visible = true;
            lblUpdateCell.Visible = true;
            lblUpdateEmail.Visible = true;
            lblupdatemsg.Visible = true;
            lblupdate.Visible = true;
            DropDownList1.Visible = true;
            btnUpdate.Visible = true;
            btnSelectID.Visible = true;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Updating selected records

            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("UPDATE EmployeeTable SET FirstName = @FirstName, Surname = @Surname, DateOfBirth = @DateOfBirth, Cell = @Cell, Email = @Email where id='" + DropDownList1.SelectedValue + "'", con);
            con.Open();

            cmd.Parameters.AddWithValue("@FirstName", txtUpdateFirstName.Text);
            cmd.Parameters.AddWithValue("@Surname", txtUpdateSurname.Text);
            cmd.Parameters.AddWithValue("@DateOfBirth", txtUpdateDoB.Text);
            cmd.Parameters.AddWithValue("@Cell", txtUpdateCell.Text );
            cmd.Parameters.AddWithValue("@Email", txtUpdateEmail.Text);
           

            cmd.ExecuteNonQuery();
            con.Close();

            txtUpdateFirstName.Visible = true;
            txtUpdateSurname.Visible = true;
            txtUpdateDoB.Visible = true;
            txtUpdateCell.Visible = true;
            txtUpdateEmail.Visible = true;
            lblUpdateFirstName.Visible = true;
            lblUpdateSurname.Visible = true;
            lblUpdateDOB.Visible = true;
            lblUpdateCell.Visible = true;
            lblUpdateEmail.Visible = true;
            lblupdatemsg.Visible = true;
            lblupdate.Visible = true;
            DropDownList1.Visible = true;
            btnUpdate.Visible = true;
            btnSelectID.Visible = true;
            lblupdatemsg.Text = "Updated";
            //if (IsPostBack)
            //{
                
            //}
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        protected void btnSelectID_Click(object sender, EventArgs e)
        {
            //Showing Controllers for Update
            txtUpdateFirstName.Visible = true;
            txtUpdateSurname.Visible = true;
            txtUpdateDoB.Visible = true;
            txtUpdateCell.Visible = true;
            txtUpdateEmail.Visible = true;
            lblUpdateFirstName.Visible = true;
            lblUpdateSurname.Visible = true;
            lblUpdateDOB.Visible = true;
            lblUpdateCell.Visible = true;
            lblUpdateEmail.Visible = true;
            btnSelectID.Visible = true;
            lblupdatemsg.Visible = true;
            lblupdate.Visible = true;
            DropDownList1.Visible = true;
            btnUpdate.Visible = true;

            //Selecting ID from dropdownlist, so that textbox can be filled with selected ID
            SqlConnection con1 = new SqlConnection(cs);
            DataTable dt = new DataTable();
            con1.Open();
            SqlDataReader myReader = null;
            SqlCommand myCommand = new SqlCommand("select * from EmployeeTable where id='" + DropDownList1.SelectedValue + "'", con1);

            myReader = myCommand.ExecuteReader();

            while (myReader.Read())
            {
                txtUpdateFirstName.Text = (myReader["FirstName"].ToString());
                txtUpdateSurname.Text = (myReader["Surname"].ToString());
                txtUpdateDoB.Text = (myReader["DateOfBirth"].ToString());
                txtUpdateCell.Text = (myReader["Cell"].ToString());
                txtUpdateEmail.Text = (myReader["Email"].ToString());

            }
            con1.Close();

        }
    }
}